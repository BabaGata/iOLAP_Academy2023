import boto3
import logging
import sys
import json

logging.basicConfig(
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s - %(funcName)s: %(message)s',
    stream=sys.stdout,
    level=logging.INFO
)
logger = logging.getLogger("avujic-academy-logging-cdk")
logger.setLevel(logging.INFO)
dynamodb = boto3.client('dynamodb', region_name='eu-central-1')
TABLE_NAME = "avujic-academy-dynamo-cdk"

def lambda_handler(event, context):
    logger.info(event)
    dynamodb.put_item(
        TableName=TABLE_NAME,
        Item={'id':{'S':event['id']},'value':{'S':event['value']}}
    )